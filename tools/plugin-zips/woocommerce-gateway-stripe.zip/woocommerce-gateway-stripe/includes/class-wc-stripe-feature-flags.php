<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Stripe_Feature_Flags {
	public const UPE_CHECKOUT_FEATURE_ATTRIBUTE_NAME = 'upe_checkout_experience_enabled';

	/**
	 * Feature flag for Amazon Pay.
	 *
	 * @var string
	 * @deprecated This feature flag will be removed in version 10.5.0. Amazon Pay is permanently enabled as of version 10.4.0.
	 */
	public const AMAZON_PAY_FEATURE_FLAG_NAME = '_wcstripe_feature_amazon_pay';

	/**
	 * Feature flag for Stripe Checkout Sessions.
	 *
	 * @var string
	 * @since 10.4.0
	 *
	 * @deprecated This feature flag will be removed in version 10.8.0. Stripe Checkout Sessions is available as of version 10.6.0.
	 */
	public const CHECKOUT_SESSIONS_FEATURE_FLAG_NAME = '_wcstripe_feature_stripe_checkout_sessions';

	/**
	 * Feature flag for Agentic Commerce.
	 *
	 * @var string
	 * @since 10.5.0
	 */
	public const AGENTIC_COMMERCE_FEATURE_FLAG_NAME = '_wcstripe_feature_agentic_commerce';

	/**
	 * Feature flag for expanding Optimized Checkout Suite in legacy checkout.
	 *
	 * @var string
	 * @since 10.6.0
	 */
	protected const EXPAND_OPTIMIZED_CHECKOUT_IN_LEGACY_CHECKOUT_FEATURE_FLAG_NAME = '_wcstripe_feature_expand_ocs_legacy_checkout';

	/**
	 * Feature flag for the WordPress Abilities API integration.
	 *
	 * @var string
	 * @since 10.8.0
	 */
	public const ABILITIES_FEATURE_FLAG_NAME = '_wcstripe_feature_abilities';

	/**
	 * Map of feature flag option names => their default "yes"/"no" value.
	 * This single source of truth makes it easier to maintain our dev tools.
	 *
	 * @var array
	 */
	protected static $feature_flags = [
		'_wcstripe_feature_upe'                                              => 'yes',
		self::AMAZON_PAY_FEATURE_FLAG_NAME                                   => 'no',
		self::CHECKOUT_SESSIONS_FEATURE_FLAG_NAME                            => 'no',
		self::AGENTIC_COMMERCE_FEATURE_FLAG_NAME                             => 'no',
		self::EXPAND_OPTIMIZED_CHECKOUT_IN_LEGACY_CHECKOUT_FEATURE_FLAG_NAME => 'no',
		self::ABILITIES_FEATURE_FLAG_NAME                                    => 'no',
	];

	/**
	 * Retrieve all defined feature flags with their default values.
	 * Note: This method is intended for use in the dev tools.
	 *
	 * @return array
	 */
	public static function get_all_feature_flags_with_defaults() {
		return self::$feature_flags;
	}

	/**
	 * Retrieve the default value for a specific feature flag.
	 *
	 * @param string $flag
	 * @return string
	 */
	public static function get_option_with_default( $flag ) {
		$default = isset( self::$feature_flags[ $flag ] ) ? self::$feature_flags[ $flag ] : 'no';
		return get_option( $flag, $default );
	}

	/**
	 * Feature flag to control Amazon Pay feature availability.
	 *
	 * @return bool
	 * @deprecated This method will be removed in a future version. Amazon Pay is permanently enabled as of version 10.4.0.
	 */
	public static function is_amazon_pay_available() {
		return true;
	}

	/**
	 * Feature flag to control the availability of Stripe Checkout Sessions.
	 *
	 * TODO: Remove this method from the class and add a new method in WC_Stripe_Helper instead in version 10.8.0 to check the necessary conditions in settings.
	 *
	 * @return bool
	 * @since 10.4.0
	 */
	public static function is_checkout_sessions_available() {
		$stripe_settings              = WC_Stripe_Helper::get_stripe_settings();
		$is_pmc_enabled               = $stripe_settings['pmc_enabled'] ?? 'no';
		$is_oc_enabled                = $stripe_settings['optimized_checkout_element'] ?? 'no';
		$is_automatic_capture_enabled = $stripe_settings['capture'] ?? 'yes';

		// Stripe checkout sessions feature can only be available if:
		// - PMC is enabled
		// - OC Suite is enabled
		// - Automatic capture is enabled (i.e. manual capture or later capture is disabled)
		// If any of the above conditions are not met, the feature is not available.
		if ( 'yes' !== $is_pmc_enabled || 'yes' !== $is_oc_enabled || 'yes' !== $is_automatic_capture_enabled ) {
			return false;
		}

		/**
		 * Filter to control the availability of the Stripe Checkout Sessions feature.
		 *
		 * @since 10.4.0
		 * @deprecated This filter will be removed in version 10.8.0. Stripe Checkout Sessions is permanently available as of version 10.6.0.
		 * @param bool $is_checkout_sessions_available Whether Stripe Checkout Sessions should be available.
		 */
		return (bool) apply_filters( 'wc_stripe_is_checkout_sessions_available', true );
	}

	/**
	 * Checks whether Stripe ECE (Express Checkout Element) feature flag is enabled.
	 * Express checkout buttons are rendered with either ECE or PRB depending on this feature flag.
	 *
	 * @return bool
	 *
	 * @deprecated 10.0.0 ECE is always enabled. This method will be removed in a future release.
	 */
	public static function is_stripe_ece_enabled() {
		return true;
	}

	/**
	 * Checks whether UPE "preview" feature flag is enabled.
	 * This allows the merchant to enable/disable UPE checkout.
	 *
	 * @return bool
	 *
	 * @deprecated 10.1.0 UPE is always enabled. This method will be removed in a future release.
	 */
	public static function is_upe_preview_enabled() {
		return true;
	}

	/**
	 * Checks whether UPE is enabled.
	 *
	 * @return bool
	 *
	 * @deprecated 10.0.0 UPE is always enabled. This method will be removed in a future release.
	 */
	public static function is_upe_checkout_enabled() {
		return true;
	}

	/**
	 * Whether the Optimized Checkout Suite should be expanded in legacy checkout.
	 *
	 * @return bool True if the Optimized Checkout Suite should be expanded in legacy checkout, false otherwise.
	 * @since 10.6.0
	 */
	public static function should_expand_ocs_in_legacy_checkout(): bool {
		if ( ! self::is_oc_available() ) {
			return false;
		}

		// Check if Optimized Checkout Suite is enabled.
		$stripe_settings = WC_Stripe_Helper::get_stripe_settings();
		if ( 'yes' !== ( $stripe_settings['optimized_checkout_element'] ?? 'no' ) ) {
			return false;
		}

		$feature_flag_enabled = 'yes' === self::get_option_with_default( self::EXPAND_OPTIMIZED_CHECKOUT_IN_LEGACY_CHECKOUT_FEATURE_FLAG_NAME );

		/**
		 * Filter to control whether the Optimized Checkout Suite should be expanded in the legacy checkout.
		 *
		 * @since 10.6.0
		 * @param bool $always_expand_ocs_in_legacy_checkout Whether the Optimized Checkout Suite should be expanded in the legacy checkout.
		 */
		return (bool) apply_filters( 'wc_stripe_expand_ocs_in_legacy_checkout', $feature_flag_enabled );
	}

	/**
	 * Whether the Optimized Checkout (OC) feature flag is enabled.
	 *
	 * @return bool
	 */
	public static function is_oc_available() {
		$stripe_settings = WC_Stripe_Helper::get_stripe_settings();
		$pmc_enabled     = $stripe_settings['pmc_enabled'] ?? 'no';
		if ( 'yes' !== $pmc_enabled ) {
			return false;
		}

		/**
		 * Filter to control the availability of the Optimized Checkout feature.
		 *
		 * @since 9.6.0
		 * @deprecated This filter will be removed in version 9.9.0. No replacement will be provided as the Optimized Checkout feature will be permanently enabled.
		 * @param bool   $default_value  The default value for the feature flag.
		 * @param string $default_pmc    The default value of the 'pmc_enabled' setting passed to the filter.
		 * @param string $pmc_enabled    The actual value of the 'pmc_enabled' setting.
		 */
		return (bool) apply_filters(
			'wc_stripe_is_optimized_checkout_available',
			true,
			'yes',
			$pmc_enabled
		);
	}

	/**
	 * Whether the WordPress Abilities API integration is enabled.
	 *
	 * Default-off during rollout. Merchants, integrators, and developers
	 * can opt in via the `wc_stripe_abilities_enabled` filter.
	 *
	 * @since 10.8.0
	 * @return bool True if enabled, false otherwise.
	 */
	public static function is_abilities_enabled(): bool {
		$is_abilities_enabled = 'yes' === self::get_option_with_default( self::ABILITIES_FEATURE_FLAG_NAME );

		/**
		 * Filter whether Stripe's Abilities API registrations are active.
		 *
		 * Composes with the `_wcstripe_feature_abilities` option: pass the
		 * option-derived bool through this filter to flip the result
		 * regardless of the stored option value.
		 *
		 * @since 10.8.0
		 *
		 * @param bool $enabled Whether to register Stripe abilities.
		 */
		return (bool) apply_filters( 'wc_stripe_abilities_enabled', $is_abilities_enabled );
	}

	/**
	 * Whether Agentic Commerce product feed is enabled.
	 *
	 * @since 10.5.0
	 * @return bool True if enabled, false otherwise.
	 */
	public static function is_agentic_commerce_enabled(): bool {
		$is_agentic_commerce_enabled = 'yes' === self::get_option_with_default( self::AGENTIC_COMMERCE_FEATURE_FLAG_NAME );

		/**
		 * Filter to control the availability of the Agentic Commerce feature.
		 *
		 * @since 10.5.0
		 * @param bool $enabled Whether Agentic Commerce is enabled. Default false.
		 */
		return (bool) apply_filters(
			'wc_stripe_is_agentic_commerce_enabled',
			$is_agentic_commerce_enabled
		);
	}
}

<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_gte_wc6_6 = defined( WC_VERSION ) && version_compare( WC_VERSION, '6.6', '>=' );

$wc_stripe_express_checkout_location_options = [
	'product'  => __( 'Product', 'woocommerce-gateway-stripe' ),
	'cart'     => __( 'Cart', 'woocommerce-gateway-stripe' ),
	'checkout' => __( 'Checkout', 'woocommerce-gateway-stripe' ),
];

$wc_stripe_default_express_checkout_locations = [ 'product', 'cart', 'checkout' ];

if ( WC_Stripe_Subscriptions_Helper::is_subscriptions_enabled() ) {
	$wc_stripe_express_checkout_location_options['change_payment_method'] = __( 'Change payment method (subscriptions)', 'woocommerce-gateway-stripe' );
	$wc_stripe_default_express_checkout_locations[]                       = 'change_payment_method';
}

return apply_filters(
	'wc_stripe_settings',
	[
		'enabled'                              => [
			'title'       => __( 'Enable/Disable', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Enable Stripe', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => '',
			'default'     => 'no',
		],
		'title'                                => [
			'title'       => __( 'Title', 'woocommerce-gateway-stripe' ),
			'type'        => $is_gte_wc6_6 ? 'safe_text' : 'text',
			'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce-gateway-stripe' ),
			'default'     => __( 'Credit Card (Stripe)', 'woocommerce-gateway-stripe' ),
			'desc_tip'    => true,
		],
		'description'                          => [
			'title'       => __( 'Description', 'woocommerce-gateway-stripe' ),
			'type'        => 'text',
			'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce-gateway-stripe' ),
			'default'     => __( 'Pay with your credit card via Stripe.', 'woocommerce-gateway-stripe' ),
			'desc_tip'    => true,
		],
		'api_credentials'                      => [
			'title' => __( 'Stripe Account Keys', 'woocommerce-gateway-stripe' ),
			'type'  => 'stripe_account_keys',
		],
		'testmode'                             => [
			'title'       => __( 'Test mode', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Enable Test Mode', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => __( 'Place the payment gateway in test mode using test API keys.', 'woocommerce-gateway-stripe' ),
			'default'     => 'yes',
			'desc_tip'    => true,
		],
		'test_publishable_key'                 => [
			'title'       => __( 'Test Publishable Key', 'woocommerce-gateway-stripe' ),
			'type'        => 'text',
			'description' => __( 'Get your API keys from your stripe account. Invalid values will be rejected. Only values starting with "pk_test_" will be saved.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'test_secret_key'                      => [
			'title'       => __( 'Test Secret Key', 'woocommerce-gateway-stripe' ),
			'type'        => 'password',
			'description' => __( 'Get your API keys from your stripe account. Invalid values will be rejected. Only values starting with "sk_test_" or "rk_test_" will be saved.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'publishable_key'                      => [
			'title'       => __( 'Live Publishable Key', 'woocommerce-gateway-stripe' ),
			'type'        => 'text',
			'description' => __( 'Get your API keys from your stripe account. Invalid values will be rejected. Only values starting with "pk_live_" will be saved.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'secret_key'                           => [
			'title'       => __( 'Live Secret Key', 'woocommerce-gateway-stripe' ),
			'type'        => 'password',
			'description' => __( 'Get your API keys from your stripe account. Invalid values will be rejected. Only values starting with "sk_live_" or "rk_live_" will be saved.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'webhook'                              => [
			'title'       => __( 'Webhook Endpoints', 'woocommerce-gateway-stripe' ),
			'type'        => 'title',
			'description' => $this->display_admin_settings_webhook_description(),
		],
		'test_webhook_secret'                  => [
			'title'       => __( 'Test Webhook Secret', 'woocommerce-gateway-stripe' ),
			'type'        => 'password',
			'description' => __( 'Get your webhook signing secret from the webhooks section in your stripe account.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'webhook_secret'                       => [
			'title'       => __( 'Webhook Secret', 'woocommerce-gateway-stripe' ),
			'type'        => 'password',
			'description' => __( 'Get your webhook signing secret from the webhooks section in your stripe account.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'inline_cc_form'                       => [
			'title'       => __( 'Inline Credit Card Form', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => __( 'Choose the style you want to show for your credit card form. When unchecked, the credit card form will display separate credit card number field, expiry date field and cvc field.', 'woocommerce-gateway-stripe' ),
			'default'     => 'no',
			'desc_tip'    => true,
		],
		'statement_descriptor'                 => [
			'title'       => __( 'Statement Descriptor', 'woocommerce-gateway-stripe' ),
			'type'        => 'text',
			'description' => __( 'Statement descriptors are limited to 22 characters, cannot use the special characters >, <, ", \, \', *, /, (, ), {, }, and must not consist solely of numbers. This will appear on your customer\'s statement in capital letters.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'short_statement_descriptor'           => [
			'title'       => __( 'Short Statement Descriptor', 'woocommerce-gateway-stripe' ),
			'type'        => 'text',
			'description' => __( 'Shortened version of the statement descriptor in combination with the customer order number.', 'woocommerce-gateway-stripe' ),
			'default'     => '',
			'desc_tip'    => true,
		],
		'capture'                              => [
			'title'       => __( 'Capture', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Capture charge immediately', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => __( 'Whether or not to immediately capture the charge. When unchecked, the charge issues an authorization and will need to be captured later. Uncaptured charges expire in 7 days.', 'woocommerce-gateway-stripe' ),
			'default'     => 'yes',
			'desc_tip'    => true,
		],
		'express_checkout'                     => [
			'title'       => __( 'Express Checkout Buttons', 'woocommerce-gateway-stripe' ),
			'label'       => sprintf(
				/* translators: 1) br tag 2) Stripe anchor tag 3) Apple anchor tag 4) Stripe dashboard opening anchor tag 5) Stripe dashboard closing anchor tag */
				__( 'Enable Express Checkout Buttons. (Apple Pay/Google Pay) %1$sBy using Apple Pay, you agree to %2$s and %3$s\'s terms of service. (Apple Pay domain verification is performed automatically in live mode; configuration can be found on the %4$sStripe dashboard%5$s.)', 'woocommerce-gateway-stripe' ),
				'<br />',
				'<a href="https://stripe.com/apple-pay/legal" target="_blank">Stripe</a>',
				'<a href="https://developer.apple.com/apple-pay/acceptable-use-guidelines-for-websites/" target="_blank">Apple</a>',
				'<a href="https://dashboard.stripe.com/settings/payments/apple_pay" target="_blank">',
				'</a>'
			),
			'type'        => 'checkbox',
			'description' => __( 'If enabled, users will be able to pay using Apple Pay or Chrome Payment Request if supported by the browser.', 'woocommerce-gateway-stripe' ),
			'default'     => 'yes',
			'desc_tip'    => true,
		],
		'express_checkout_button_type'         => [
			'title'       => __( 'Express Checkout Button Type', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Button Type', 'woocommerce-gateway-stripe' ),
			'type'        => 'select',
			'description' => __( 'Select the button type you would like to show.', 'woocommerce-gateway-stripe' ),
			'default'     => 'default',
			'desc_tip'    => true,
			'options'     => [
				'default' => __( 'Only icon', 'woocommerce-gateway-stripe' ),
				'buy'     => __( 'Buy', 'woocommerce-gateway-stripe' ),
				'donate'  => __( 'Donate', 'woocommerce-gateway-stripe' ),
				'book'    => __( 'Book', 'woocommerce-gateway-stripe' ),
			],
		],
		'express_checkout_button_theme'        => [
			'title'       => __( 'Express Checkout Button Theme', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Button Theme', 'woocommerce-gateway-stripe' ),
			'type'        => 'select',
			'description' => __( 'Select the button theme you would like to show.', 'woocommerce-gateway-stripe' ),
			'default'     => 'dark',
			'desc_tip'    => true,
			'options'     => [
				'dark'          => __( 'Dark', 'woocommerce-gateway-stripe' ),
				'light'         => __( 'Light', 'woocommerce-gateway-stripe' ),
				'light-outline' => __( 'Light-Outline', 'woocommerce-gateway-stripe' ),
			],
		],
		'express_checkout_button_height'       => [
			'title'       => __( 'Express Checkout Button Height', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Button Height', 'woocommerce-gateway-stripe' ),
			'type'        => 'text',
			'description' => __( 'Enter the height you would like the button to be in pixels. Width will always be 100%.', 'woocommerce-gateway-stripe' ),
			'default'     => '44',
			'desc_tip'    => true,
		],
		'express_checkout_button_label'        => [
			'title'       => __( 'Express Checkout Button Label', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Button Label', 'woocommerce-gateway-stripe' ),
			'type'        => 'text',
			'description' => __( 'Enter the custom text you would like the button to have.', 'woocommerce-gateway-stripe' ),
			'default'     => __( 'Buy now', 'woocommerce-gateway-stripe' ),
			'desc_tip'    => true,
		],
		'express_checkout_button_branded_type' => [
			'title'       => __( 'Express Checkout Branded Button Label Format', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Branded Button Label Format', 'woocommerce-gateway-stripe' ),
			'type'        => 'select',
			'description' => __( 'Select the branded button label format.', 'woocommerce-gateway-stripe' ),
			'default'     => 'long',
			'desc_tip'    => true,
			'options'     => [
				'short' => __( 'Logo only', 'woocommerce-gateway-stripe' ),
				'long'  => __( 'Text and logo', 'woocommerce-gateway-stripe' ),
			],
		],
		'express_checkout_button_locations'    => [
			'title'             => __( 'Express Checkout Button Locations', 'woocommerce-gateway-stripe' ),
			'type'              => 'multiselect',
			'description'       => __( 'Select where you would like Express Checkout Buttons to be displayed', 'woocommerce-gateway-stripe' ),
			'desc_tip'          => true,
			'class'             => 'wc-enhanced-select',
			'options'           => $wc_stripe_express_checkout_location_options,
			'default'           => $wc_stripe_default_express_checkout_locations,
			'custom_attributes' => [
				'data-placeholder' => __( 'Select pages', 'woocommerce-gateway-stripe' ),
			],
		],
		'express_checkout_button_size'         => [
			'title'       => __( 'Express Checkout Button Size', 'woocommerce-gateway-stripe' ),
			'type'        => 'select',
			'description' => __( 'Select the size of the button.', 'woocommerce-gateway-stripe' ),
			'default'     => 'default',
			'desc_tip'    => true,
			'options'     => [
				'small'   => __( 'Small (40px)', 'woocommerce-gateway-stripe' ),
				'default' => __( 'Default (48px)', 'woocommerce-gateway-stripe' ),
				'large'   => __( 'Large (56px)', 'woocommerce-gateway-stripe' ),
			],
		],
		'saved_cards'                          => [
			'title'       => __( 'Saved payment methods', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Enable saved payment methods', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => __( 'If enabled, returning customers can check out using payment details securely stored by Stripe. No payment information is stored on your store.', 'woocommerce-gateway-stripe' ),
			'default'     => 'yes',
			'desc_tip'    => true,
		],
		'sepa_tokens_for_ideal'                => [
			'title'       => __( 'SEPA Direct Debit tokens when saving iDEAL | Wero methods', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Enable saved iDEAL | Wero payments for repeat payments', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => __( 'If enabled, users will be able to pay with iDEAL | Wero and save the method as a SEPA Direct Debit method.', 'woocommerce-gateway-stripe' ),
			'default'     => 'no',
			'desc_tip'    => true,
		],
		'sepa_tokens_for_bancontact'           => [
			'title'       => __( 'SEPA Direct Debit tokens when saving Bancontact methods', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Enable saved Bancontact payments for repeat payments', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => __( 'If enabled, users will be able to pay with Bancontact and save the method as a SEPA Direct Debit method.', 'woocommerce-gateway-stripe' ),
			'default'     => 'no',
			'desc_tip'    => true,
		],
		'logging'                              => [
			'title'       => __( 'Logging', 'woocommerce-gateway-stripe' ),
			'label'       => __( 'Log debug messages', 'woocommerce-gateway-stripe' ),
			'type'        => 'checkbox',
			'description' => __( 'Save debug messages to the WooCommerce System Status log.', 'woocommerce-gateway-stripe' ),
			'default'     => 'no',
			'desc_tip'    => true,
		],
		'amazon_pay_button_locations'          => [
			'title'             => __( 'Amazon Pay Button Locations', 'woocommerce-gateway-stripe' ),
			'type'              => 'multiselect',
			'description'       => __( 'Select where you would like Amazon Pay Button to be displayed', 'woocommerce-gateway-stripe' ),
			'desc_tip'          => true,
			'class'             => 'wc-enhanced-select',
			'options'           => [
				'product'  => __( 'Product', 'woocommerce-gateway-stripe' ),
				'cart'     => __( 'Cart', 'woocommerce-gateway-stripe' ),
				'checkout' => __( 'Checkout', 'woocommerce-gateway-stripe' ),
			],
			'default'           => [ 'product', 'cart', 'checkout' ],
			'custom_attributes' => [
				'data-placeholder' => __( 'Select pages', 'woocommerce-gateway-stripe' ),
			],
		],
		'amazon_pay_button_size'               => [
			'title'       => __( 'Amazon Pay Button Size', 'woocommerce-gateway-stripe' ),
			'type'        => 'select',
			'description' => __( 'Select the size of the button.', 'woocommerce-gateway-stripe' ),
			'default'     => 'default',
			'desc_tip'    => true,
			'options'     => [
				'small'   => __( 'Small (40px)', 'woocommerce-gateway-stripe' ),
				'default' => __( 'Default (48px)', 'woocommerce-gateway-stripe' ),
				'large'   => __( 'Large (56px)', 'woocommerce-gateway-stripe' ),
			],
		],
		'optimized_checkout_layout'            => [
			'title'       => __( 'Optimized Checkout Layout', 'woocommerce-gateway-stripe' ),
			'type'        => 'select',
			'description' => __( 'Select the layout of the container.', 'woocommerce-gateway-stripe' ),
			'default'     => WC_Stripe_UPE_Payment_Gateway::OPTIMIZED_CHECKOUT_DEFAULT_LAYOUT,
			'desc_tip'    => true,
			'options'     => [
				'accordion' => __( 'Accordion', 'woocommerce-gateway-stripe' ),
				'tabs'      => __( 'Tabs', 'woocommerce-gateway-stripe' ),
			],
		],
	]
);
